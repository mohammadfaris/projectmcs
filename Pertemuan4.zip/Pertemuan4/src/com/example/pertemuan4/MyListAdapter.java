package com.example.pertemuan4;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class MyListAdapter extends BaseAdapter{

	ArrayList<String> items = new ArrayList<String>();
	Context c;
	
	public MyListAdapter() {
		//constructor memanggil objek jalanin pertama kali
		// TODO Auto-generated constructor stub
	}
	
	public MyListAdapter(Context c) {
		// TODO Auto-generated constructor stub
		this.c=c;
	}
	
	public void setItem(String item){
		items.add(item);		
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return items.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		if(convertView == null){
			convertView = LayoutInflater.from(c).inflate(R.layout.adapter_view, null);
		}
		TextView t = (TextView) convertView.findViewById(R.id.adapterView);//buat ubah si textview
		t.setText(items.get(position));
		
		return convertView;
	}
	
}
