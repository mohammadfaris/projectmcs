/** Automatically generated file. DO NOT MODIFY */
package com.example.pertemuan5;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}