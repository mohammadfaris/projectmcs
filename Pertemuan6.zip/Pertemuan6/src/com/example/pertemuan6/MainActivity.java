package com.example.pertemuan6;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends Activity implements OnClickListener{

	EditText txtFileName;
	EditText txtData;
	Button btnWrite;
	Button btnRead;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        txtFileName = (EditText) findViewById(R.id.txtFileName);
        txtData= (EditText) findViewById(R.id.txtData);
        
        btnWrite = (Button) findViewById(R.id.btnWrite);
        btnWrite.setOnClickListener(this);
        btnRead = (Button) findViewById(R.id.btnRead);
        btnRead.setOnClickListener(this);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.equals(btnWrite)){
			
			//Internal
			/*
			try {
				FileOutputStream fOut = openFileOutput(txtFileName.getText().toString(), Context.MODE_PRIVATE);
				fOut.write(txtData.getText().toString().getBytes());
				fOut.close();
				Toast.makeText(this, "Success", Toast.LENGTH_LONG).show();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			*/
			File myFile = new File("/sdcard/"+txtFileName.getText().toString());
			try {
				FileOutputStream fOut = new FileOutputStream(myFile);
				OutputStreamWriter writer = new OutputStreamWriter(fOut);
				writer.append(txtData.getText().toString());
				writer.close();
				fOut.close();
				Toast.makeText(this, "Success", Toast.LENGTH_SHORT).show();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(v.equals(btnRead)){
			String temp;
			String data = "";
			
			//Internal
			/*
			try {
				FileInputStream fIn = openFileInput(txtFileName.getText().toString());
				InputStreamReader isr = new InputStreamReader(fIn);
				BufferedReader br = new BufferedReader(isr);
				while( (temp = br.readLine()) != null){
					data += temp + "\n";
				}
				fIn.close();
				Toast.makeText(this, data, Toast.LENGTH_LONG).show();
			}catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			*/
			try {
				File myFile = new File("/sdcard/"+txtFileName.getText().toString());
				FileInputStream fIn = new FileInputStream(myFile);
				InputStreamReader isr = new InputStreamReader(fIn);
				BufferedReader br = new BufferedReader(isr);
				while( (temp = br.readLine()) != null){
					data += temp + "\n";
				}
				fIn.close();
				Toast.makeText(this, data, Toast.LENGTH_LONG).show();
			}catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
